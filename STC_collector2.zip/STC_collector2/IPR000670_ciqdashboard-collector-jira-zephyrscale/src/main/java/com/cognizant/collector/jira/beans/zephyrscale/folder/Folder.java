package com.cognizant.collector.jira.beans.zephyrscale.folder;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

import java.util.*;

@Data
public class Folder {

    @JsonProperty("id")
    private long id;

    @JsonProperty("projectId")
    private long projectId;

    @JsonProperty("index")
    private long index;

    @JsonProperty("name")
    private String name;

    @JsonProperty("itemsCount")
    private long itemsCount;

    @JsonProperty("children")
    private Folder[] subFolders;

    @JsonProperty("createdBy")
    private String createdBy;

    @JsonProperty("createdOn")
    private Date createdOn;

    @JsonProperty("updatedBy")
    private String updatedBy;

    @JsonProperty("updatedOn")
    private Date updatedOn;

    @JsonProperty("parentId")
    private Long parentId;

}
