package com.cognizant.collector.jira.beans.zephyrscale.testrun;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

import java.util.*;

@Data
public class TestCase {

    @JsonProperty("executedBy")
    private String executedBy;
    @JsonProperty("actualEndDate")
    private Date actualEndDate;
    @JsonProperty("actualStartDate")
    private Date actualStartDate;
    @JsonProperty("id")
    private long id;
    @JsonProperty("userKey")
    private String userKey;
    @JsonProperty("status")
    private String status;
    @JsonProperty("executionDate")
    private Date executionDate;
    @JsonProperty("assignedTo")
    private String assignedTo;
    @JsonProperty("testCaseKey")
    private String testCaseKey;

}
