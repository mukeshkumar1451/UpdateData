package com.cognizant.collector.jira.util;

import com.cognizant.collector.jira.beans.zephyrscale.customfield.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.*;
import lombok.extern.slf4j.*;

import java.io.*;

@Slf4j
public class OptionInfoDeserializer extends JsonDeserializer {

    @Override
    public OptionInfo deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException, JacksonException {

        ArrayNode arrayNode = jsonParser.getCodec().readTree(jsonParser);
        OptionInfo options = new OptionInfo();

        arrayNode.forEach(node -> {
            try {
                Option option = jsonParser.getCodec().treeToValue(node, Option.class);
                options.getOptions().put(option.getId(), option);
            } catch (JsonProcessingException e) {
                log.warn("Unknown error occurred while deserializing custom field options : {}", node);
            }
        });

        return options;
    }
}
