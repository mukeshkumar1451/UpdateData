package com.cognizant.collector.jira.beans.zephyrscale.testcase;

import com.cognizant.collector.jira.beans.zephyrscale.*;
import com.fasterxml.jackson.annotation.*;
import lombok.*;
import org.springframework.beans.*;

import java.util.*;

@Data
public class TestCase {

    @JsonProperty("majorVersion")
    private long majorVersion;

    @JsonProperty("priority")
    private Category priority;

    @JsonProperty("labels")
    private String[] labels;

    @JsonProperty("archived")
    private boolean archived;

    @JsonProperty("folder")
    private Folder folder;

    @JsonProperty("customFieldValues")
    private List<CustomField> customFieldValues = new ArrayList<>();

    @JsonProperty("averageTime")
    private Long averageTime;

    @JsonProperty("latestVersion")
    private boolean latestVersion;

    @JsonProperty("name")
    private String name;

    @JsonProperty("id")
    private long id;

    @JsonProperty("projectId")
    private long projectId;

    @JsonProperty("key")
    private String key;

    @JsonProperty("status")
    private Category status;

    @JsonProperty("lastTestResultStatus")
    private Category lastTestResultStatus;

    @JsonProperty("createdOn")
    private Date createdOn;

    @JsonProperty("createdBy")
    private String createdBy;

    @JsonProperty("updatedOn")
    private Date updatedOn;

    @JsonProperty("updatedBy")
    private String updatedBy;

    @JsonIgnore
    public ZephyrScaleTestCase setPriority(ZephyrScaleTestCase testCase) {

        if(priority==null) return testCase;
        testCase.setPriorityId(this.priority.getId());
        testCase.setPriorityName(this.priority.getName());
        testCase.setPriorityIndex(this.priority.getIndex());
        testCase.setPriorityIsDefault(this.priority.isDefault());

        return testCase;
    }

    @JsonIgnore
    public ZephyrScaleTestCase setStatus(ZephyrScaleTestCase testCase) {
        if(status==null) return testCase;
        testCase.setStatusId(this.status.getId());
        testCase.setStatusName(this.status.getName());
        testCase.setStatusIndex(this.status.getIndex());
        testCase.setStatusIsDefault(this.status.isDefault());

        return testCase;
    }

    @JsonIgnore
    public ZephyrScaleTestCase setLastTestResultStatus(ZephyrScaleTestCase testCase) {
        if(lastTestResultStatus==null) return testCase;
        testCase.setLastTestResultStatusId(this.lastTestResultStatus.getId());
        testCase.setLastTestResultStatusName(this.getLastTestResultStatus().getName());
        testCase.setLastTestResultStatusIsDefault(this.getLastTestResultStatus().isDefault());

        return testCase;
    }

    @JsonIgnore
    public ZephyrScaleTestCase setFolder(ZephyrScaleTestCase testCase) {
        if(folder==null) return testCase;
        testCase.setFolderId(this.folder.getId());
        // We need to change the folder class here
       // System.out.println("--------------------------------");
      // System.out.println("Folder Name is " + this.folder.getName());
       // System.out.println("--------------------------------");
        testCase.setFolderName(this.folder.getName());
        return testCase;
    }

    @JsonIgnore
    public ZephyrScaleTestCase getZephyrScaleTestCase(ZephyrScaleTestCase testCase) {
        BeanUtils.copyProperties(this, testCase);

        this.setPriority(testCase);
        this.setStatus(testCase);
        this.setFolder(testCase);
        this.setLastTestResultStatus(testCase);

        return testCase;
    }

}