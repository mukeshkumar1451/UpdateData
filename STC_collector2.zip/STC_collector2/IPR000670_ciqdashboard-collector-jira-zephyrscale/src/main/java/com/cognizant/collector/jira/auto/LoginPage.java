package com.cognizant.collector.jira.auto;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import javax.annotation.*;

@Component
public class LoginPage {

    @Autowired
    WebDriver webDriver;

    @FindBy(how = How.ID, using = "email")
    WebElement emailTextBox;

    @FindBy(how = How.ID, using = "password")
    WebElement passwordTextBox;

    @FindBy(how = How.XPATH, using = "//a[text()='@stc.com.sa']")
    WebElement emailIdSuggestion;

    @FindBy(how = How.ID, using = "loginText")
    WebElement loginButton;

    @PostConstruct
    public void initLogin() {
        PageFactory.initElements(webDriver, this);
    }

    @PreDestroy
    public void destructLogin() {
        webDriver.quit();
    }

    public void login(String username, String password) {
        emailTextBox.sendKeys(username);
        emailIdSuggestion.click();
        passwordTextBox.sendKeys(password);
        loginButton.click();
    }

    public String getTitle() {
        return webDriver.getTitle();
    }

    public void logout() {
        webDriver.quit();
    }

}
