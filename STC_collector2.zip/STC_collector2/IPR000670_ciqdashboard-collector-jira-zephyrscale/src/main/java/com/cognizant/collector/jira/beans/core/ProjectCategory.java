package com.cognizant.collector.jira.beans.core;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
public class ProjectCategory {

    @JsonProperty("id")
    private String id;

    @JsonProperty("name")
    private String name;

}
