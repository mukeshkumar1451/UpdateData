package com.cognizant.collector.jira.service;

import com.cognizant.collector.jira.beans.metadata.*;
import com.cognizant.collector.jira.db.repo.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import java.time.*;

@Service
public class SchedulerInfoService {

    @Autowired
    SchedulerInfoRepository schedulerRepository;

    public void save(String[] toolNames) {

        LocalDateTime currentTime = LocalDateTime.now().atOffset(ZoneOffset.UTC).toLocalDateTime();

        for (String toolName : toolNames) {

            SchedulerInfo schedulerInfo = new SchedulerInfo();
            schedulerInfo.setToolName(toolName);
            schedulerInfo.setDesc(toolName+" scheduler info");
            schedulerInfo.setLastUpdatedDate(currentTime);

            var schedulerInfoFromDB = schedulerRepository.findFirstByToolName(toolName);
            schedulerInfoFromDB.ifPresent(info -> {
                schedulerInfo.setId(info.getId());
            });
            schedulerRepository.save(schedulerInfo);
        }
    }

}
