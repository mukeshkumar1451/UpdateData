package com.cognizant.collector.jira.beans.zephyrscale.testrun;

import com.cognizant.collector.jira.beans.Project;
import com.cognizant.collector.jira.beans.zephyrscale.*;
import com.cognizant.collector.jira.beans.zephyrscale.folder.*;
import com.cognizant.collector.jira.component.CommonUtilComponent;
import com.fasterxml.jackson.annotation.*;
import lombok.*;
import org.jsoup.*;

import java.util.*;
import java.util.stream.*;

@Data
public class TestRun {

    @JsonProperty("estimatedTime")
    private long estimatedTime;
    @JsonProperty("updatedBy")
    private String updatedBy;
    private String description;

    @JsonProperty("description")
    public void setDescription(String description) {
        if(description!=null) this.description = Jsoup.parse(description).text();
    }

    @JsonProperty("updatedOn")
    private Date updatedOn;
    @JsonProperty("issueCount")
    private long issueCount;
    @JsonProperty("createdOn")
    private Date createdOn;
    @JsonProperty("plannedEndDate")
    private Date plannedEndDate;
    @JsonProperty("executionTime")
    private long executionTime;
    @JsonProperty("projectKey")
    private String projectKey;
    @JsonProperty("testCaseCount")
    private long testCaseCount;
    @JsonProperty("folder")
    private String folder;
    @JsonProperty("version")
    private String version;
    @JsonProperty("plannedStartDate")
    private Date plannedStartDate;
    @JsonProperty("createdBy")
    private String createdBy;
    @JsonProperty("name")
    private String name;
    @JsonProperty("items")
    private List<TestCase> testCases = new ArrayList<>();
    @JsonProperty("key")
    private String key;
    @JsonProperty("executionSummary")
    private ExecutionSummary executionSummary;
    @JsonProperty("status")
    private String status;
    @JsonProperty("owner")
    private String owner;

    private String type = "Test Run";

    @JsonIgnore
    public Stream<ZephyrScaleTestRun> getZephyrScaleTestRuns(Project project, Folder parentFolder) {
        return this.testCases.stream().map(testCase -> {
            ZephyrScaleTestRun zephyrScaleTestRun= new ZephyrScaleTestRun();

            zephyrScaleTestRun.setId(testCase.getId());
            zephyrScaleTestRun.setDescription(this.description);
            zephyrScaleTestRun.setType(this.type);
            zephyrScaleTestRun.setTestCaseKey(testCase.getTestCaseKey());
            zephyrScaleTestRun.setTestCaseStatus(CommonUtilComponent.getOrderedStatusName(testCase.getStatus()));
            zephyrScaleTestRun.setExecutionSummary(this.executionSummary);

            zephyrScaleTestRun.setProjectId(project.getId());
            zephyrScaleTestRun.setProjectKey(project.getKey());
            zephyrScaleTestRun.setProjectName(project.getName());
            zephyrScaleTestRun.setProjectCategoryId(project.getProjectCategory().getId());
            zephyrScaleTestRun.setProjectCategoryName(project.getProjectCategory().getName());

            zephyrScaleTestRun.setVersion(this.version);
            zephyrScaleTestRun.setFolder(this.folder);

            zephyrScaleTestRun.setCycleKey(this.key);
            zephyrScaleTestRun.setCycleName(this.name);
            zephyrScaleTestRun.setCycleExecutionStatus(this.status);

            zephyrScaleTestRun.setOwner(this.owner);
            zephyrScaleTestRun.setAssignedTo(testCase.getAssignedTo());
            zephyrScaleTestRun.setUserKey(testCase.getUserKey());

            zephyrScaleTestRun.setCreatedOn(this.createdOn);
            zephyrScaleTestRun.setCreatedBy(this.createdBy);
            zephyrScaleTestRun.setPlannedStartDate(this.plannedStartDate);
            zephyrScaleTestRun.setPlannedEndDate(this.plannedEndDate);
            zephyrScaleTestRun.setActualStartDate(testCase.getActualStartDate());
            zephyrScaleTestRun.setActualEndDate(testCase.getActualEndDate());
            zephyrScaleTestRun.setExecutedBy(testCase.getExecutedBy());
            zephyrScaleTestRun.setExecutionDate(testCase.getExecutionDate());
            zephyrScaleTestRun.setUpdatedBy(this.updatedBy);
            zephyrScaleTestRun.setUpdatedOn(this.updatedOn);

            zephyrScaleTestRun.setEstimatedTime(this.estimatedTime);
            zephyrScaleTestRun.setExecutionTime(this.executionTime);

            zephyrScaleTestRun.setIssueCount(this.issueCount);
            zephyrScaleTestRun.setTestCaseCount(this.testCaseCount);

            zephyrScaleTestRun.setFirstFolderId(parentFolder.getId());
            zephyrScaleTestRun.setFirstFolderName(parentFolder.getName());

            return zephyrScaleTestRun;
        });
    }

}
