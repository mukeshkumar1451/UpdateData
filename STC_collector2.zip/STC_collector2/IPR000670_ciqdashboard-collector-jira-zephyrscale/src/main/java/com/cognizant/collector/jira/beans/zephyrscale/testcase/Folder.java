package com.cognizant.collector.jira.beans.zephyrscale.testcase;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
public class Folder {

    @JsonProperty("parent")
    private Folder parentFolder;

    @JsonProperty("id")
    private Long id;

    @JsonProperty("name")
    private String name;

}
