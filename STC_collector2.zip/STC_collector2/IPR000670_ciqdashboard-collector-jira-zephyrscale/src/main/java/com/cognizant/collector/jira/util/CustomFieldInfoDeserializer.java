package com.cognizant.collector.jira.util;

import com.cognizant.collector.jira.beans.zephyrscale.customfield.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.*;
import lombok.extern.slf4j.*;

import java.io.*;

@Slf4j
public class CustomFieldInfoDeserializer extends JsonDeserializer {

    @Override
    public CustomFieldInfo deserialize(JsonParser jsonParser, DeserializationContext ctxt) throws IOException, JacksonException {

        ArrayNode arrayNode = jsonParser.getCodec().readTree(jsonParser);
        CustomFieldInfo customFields = new CustomFieldInfo();

        arrayNode.forEach(node -> {
            try {
                CustomField customField = jsonParser.getCodec().treeToValue(node, CustomField.class);
                customFields.getCustomFields().put(customField.getId(), customField);
            } catch (JsonProcessingException e) {
                log.warn("Unknown error occurred while deserializing custom fields : {}", node);
            }
        });

        return customFields;
    }

}
