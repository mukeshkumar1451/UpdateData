/*
 *  © [2021] Cognizant. All rights reserved.
 *
 *     Licensed under the Apache License, Version 2.0 (the "License");
 *     you may not use this file except in compliance with the License.
 *     You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *     Unless required by applicable law or agreed to in writing, software
 *     distributed under the License is distributed on an "AS IS" BASIS,
 *     WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *     See the License for the specific language governing permissions and
 *     limitations under the License.
 */

package com.cognizant.collector.jira.component;

import com.cognizant.collector.jira.beans.core.*;
import com.cognizant.collector.jira.beans.zephyrscale.*;
import com.cognizant.collector.jira.beans.zephyrscale.customfield.*;
import com.cognizant.collector.jira.beans.zephyrscale.testcase.CustomField;
import com.cognizant.collector.jira.service.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.jetbrains.annotations.Nullable;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

import static com.cognizant.collector.jira.constants.Constant.*;
/**
 * CommonUtilComponent
 * @author Cognizant
 */

@Component
@Slf4j
public class CommonUtilComponent {

    @Autowired
    JiraIssueService service;

    static String jiraCollectionName;
    static String zephyrCollectionName;

    static String strLocale;
    static String timeZone;

    private static final String DELIMITER =";";

    public static String getJiraCollectionName() {
        return jiraCollectionName;
    }

    public static String getOrderedStatusName(String statusName) {

        switch(statusName) {
            case "Pass":
                return "01-Pass";
            case "Not Executed":
            case "Not Executed - RFT":
                return "03-Not Executed";
            case "Fail":
                return "04-Fail";
            case "Blocked":
            case "Blocked - Email / Data":
                return "05-Blocked";
            case "Deferred":
                return "06-Deferred";
            case "Not Deployed":
                return "07-Deployed";
            case "Pending FRS Update":
                return "08-Pending FRS Update";
            case "Not Applicable":
                return "09-Not Applicable";
            case "Out of Scope":
                return "10-Out of Scope";
            case "In Progress":
                return "02-In Progress";
            default:
                log.warn("Unhandled status found {}, returning U-status (U = Unknown)", statusName);
                return "U-"+statusName;

        }
    }

    @Value("${spring.data.mongodb.collection.issue}")
    public void setJiraCollectionName(String jiraCollectionName) {
        CommonUtilComponent.jiraCollectionName = SOURCE_JIRA + jiraCollectionName;
    }

    public static String getZephyrCollectionName() {
        return zephyrCollectionName;
    }

    @Value("${spring.data.mongodb.collection.testRun}")
    public void setZephyrCollectionName(String zephyrCollectionName) {
        CommonUtilComponent.zephyrCollectionName = SOURCE_ZEPHYR + zephyrCollectionName;
    }

    public String decodeBase64String(String encodedString) {
        try {
            byte[] decodedData = Base64.decodeBase64(encodedString);
            String decodedString = new String(decodedData, "UTF-8");
            return decodedString;
        } catch (UnsupportedEncodingException e) {
            log.warn("Base64 decoding failed, returning null", e);
            return null;
        }
    }

    public String parseDateToString(Date date) {
        if (null == date) {
            return "";
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
        return sdf.format(date);
    }

    public Date getDateFromString(String dateString) {
        Date date = null;
        try {
            LocalDateTime dateTime = LocalDateTime.parse(dateString, DateTimeFormatter.ISO_DATE_TIME);
            date = Date.from(dateTime.atZone(TimeZone.getTimeZone(timeZone).toZoneId()).toInstant());
        } catch (DateTimeParseException e) {
            log.warn("Return value as null, due to exception while parsing string to date, Exception:",e);
        }
        return date;
    }

    public Integer getIntegerFromString(String integerString) {
        Integer integer = null;
        try {
            integer = Integer.valueOf(integerString);
        } catch (NumberFormatException e) {
            log.warn("Return value as null, due to exception while parsing string to integer, Exception:",e);
        }
        return integer;
    }

    public Map<String, String> getMap(String input) {
        Map<String, String> map = new HashMap<>();
        if (!(input.contains("[") && input.contains("]"))) return map;

        String[] strings = input.substring(input.indexOf('[') + 1, input.indexOf(']')).split(",");
        List<String> list = Arrays.asList(strings);
        list.forEach(s -> {
            String[] split = s.split("=");
            String key = split[0];
            if (split.length == 2) {
                String value = split[1].equals("<null>") ? null : split[1];
                map.put(key, value);
            }
        });

        return map;
    }

    public String getJqlParamString(String projectKey, Date lastUpdatedDate) {
        List<String> jqlParams = new ArrayList<>();
        jqlParams.add(String.format(PROJECT, projectKey));
        Date now = Calendar.getInstance().getTime();
        String nowDateSting = parseDateToString(now);
        jqlParams.add(String.format(JQL_UPDATED_LT, nowDateSting));
        if (!StringUtils.isEmpty(lastUpdatedDate)) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(lastUpdatedDate);
            calendar.add(Calendar.MINUTE, 1);
            String updatedDateString = parseDateToString(calendar.getTime());
            jqlParams.add(String.format(JQL_UPDATED_GTE, updatedDateString));
        }
        String jqlString = jqlParams.stream().collect(Collectors.joining(JQL_AND))+JQL_ORDER_BY_UPDATED;
        log.info("JQL string : " + jqlString);
        System.out.print("----------------->>>>>>>>");
        System.out.println(jqlString);
        System.out.print("----------------->>>>>>>>");
        return jqlString;
    }

    public SprintDetails getSprintDetailsFromString(String input){
        if (StringUtils.isEmpty(input)) return null;
        SprintDetails sprintDetails = new SprintDetails();
        Map<String, String> map = getMap(input);
        String id = map.get("id");
        String rapidViewId = map.get("rapidViewId");
        String state = map.get("state");
        String name = map.get("name");
        String startDate = map.get("startDate");
        String endDate = map.get("endDate");
        String completeDate = map.get("completeDate");
        String activatedDate = map.get("activatedDate");
        String sequence = map.get("sequence");
        String goal = map.get("goal");

        sprintDetails.setSprintId(getIntegerFromString(id));
        sprintDetails.setSprintRapidViewId(getIntegerFromString(rapidViewId));
        sprintDetails.setSprintSequence(getIntegerFromString(sequence));

        sprintDetails.setSprintActivatedDate(getDateFromString(activatedDate));
        sprintDetails.setSprintCompleteDate(getDateFromString(completeDate));
        sprintDetails.setSprintEndDate(getDateFromString(endDate));
        sprintDetails.setSprintStartDate(getDateFromString(startDate));

        sprintDetails.setSprintGoal(goal);
        sprintDetails.setSprintName(name);
        sprintDetails.setSprintState(state);

        return sprintDetails;
    }

    public String getZephyrScaleTestRunQuery(String projectKey, String folderName) {
        String Query= String.format(TEST_RUN_QUERY, projectKey, folderName);
        System.out.println("Query: " + Query);
        return Query;
    }

    public String getZephyrScaleTestCaseQuery(String projectId, String folderId) {
        return String.format(TEST_CASE_QUERY, projectId, folderId);
    }

    public ZephyrScaleTestCase setCustomFieldDetails(ZephyrScaleTestCase testCase, List<CustomField> customFieldValues, CustomFieldInfo customFieldInfo) {

        customFieldValues.forEach(customFieldValue -> {

            com.cognizant.collector.jira.beans.zephyrscale.customfield.CustomField customField = customFieldInfo.getCustomFields().get(customFieldValue.getCustomFieldId());
            var value = this.getCustomFieldValue(customFieldValue, customField);

            switch(customField.getName()) {

                case "SR_Classification":
                    testCase.setSrClassification(value);
                    break;
                case "SR_Type":
                    testCase.setSrType(value);
                    break;
                case "Language":
                    testCase.setLanguage(value);
                    break;
                case "Req_ID_All":
                    testCase.setReqIdAll(value);
                    break;
                case "Req_ID":
                    testCase.setReqId(value);
                    break;
                case "SR_Action":
                    testCase.setSrAction(value);
                    break;
                case "Wave#":
                    testCase.setWave(value);
                    break;
                case "SR_SubArea":
                    testCase.setSrSubArea(value);
                    break;
                case "Release":
                    testCase.setRelease(value);
                    break;
                case "UseCaseID":
                    testCase.setUseCaseId(value);
                    break;
                case "SR_Area":
                    testCase.setSrArea(value);
                    break;
                case "TestEnvironment":
                    testCase.setTestEnvironment(value);
                    break;
                case "TestType":
                    testCase.setTestType(value);
                    break;
                case "Cycle":
                    testCase.setCycleName(value);
                    break;
                case "Drop/Release":
                    testCase.setDropName(value);
                    break;
                default:
                    log.info("An unhandled custom field has been encountered : {}", customField.getName());
                    break;

            }

        });

        return testCase;

    }

    @Nullable
    private String getCustomFieldValue(CustomField customFieldValue, com.cognizant.collector.jira.beans.zephyrscale.customfield.CustomField customField) {
        Optional<String> data = Optional.ofNullable(customFieldValue.getStringValue());

        return data.orElseGet(
                () -> {
                    if(customFieldValue.getIntValue()==null) {
                        return null;
                    }
                    else if(customField.getOptionInfo()==null) {
                        log.warn("Custom field options were not found, so null was returned for the custom field : {} ", customField);
                        return null;
                    }
                    return customField.getOptionInfo().getOptions().get(customFieldValue.getIntValue()).getName();
                }
        );
    }

    public LocalDateTime nullifyHoursMinutesAndSeconds(Date date) {
        return date.toInstant()
                .atZone(TimeZone.getTimeZone(timeZone).toZoneId())
                .toLocalDateTime().toLocalDate().atTime(LocalTime.MAX);
    }

    public long getDifferenceBetweenDates(Date stardate, Date enddate) {
        return Duration.between(
                this.nullifyHoursMinutesAndSeconds(stardate),
                this.nullifyHoursMinutesAndSeconds(enddate)
        ).toDays();
    }

    public static String orderPriorityUsingNumbers(String priority) {
        switch(priority) {
            case "Blocker":
                return "1-"+priority;
            case "Critical":
                return "2-"+priority;
            case "High":
                return "3-"+priority;
            case "Medium":
                return "4-"+priority;
            case "Low":
                return "5-"+priority;
            default:
                log.warn("Unhandled priority found {}, returning U-priority (U = Unknown)", priority);
                return "U-"+priority;
        }
    }

    public static  String convertListToString(List<String> list){
        if(list==null) return "";
        return list.stream().collect(Collectors.joining(DELIMITER));
    }



}
