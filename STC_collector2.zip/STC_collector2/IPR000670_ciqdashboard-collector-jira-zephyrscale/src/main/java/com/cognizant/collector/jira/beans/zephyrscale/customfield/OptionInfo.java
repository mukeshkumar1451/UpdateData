package com.cognizant.collector.jira.beans.zephyrscale.customfield;

import com.cognizant.collector.jira.util.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.*;

import java.util.*;

@Data
@JsonDeserialize(using = OptionInfoDeserializer.class)
public class OptionInfo {

    Map<Long, Option> options = new HashMap<Long, Option>();

}
