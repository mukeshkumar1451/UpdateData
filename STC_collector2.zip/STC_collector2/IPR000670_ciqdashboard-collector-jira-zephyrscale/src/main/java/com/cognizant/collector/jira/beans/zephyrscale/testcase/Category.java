package com.cognizant.collector.jira.beans.zephyrscale.testcase;

import com.cognizant.collector.jira.component.CommonUtilComponent;
import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
public class Category {

    @JsonProperty("isDefault")
    private boolean isDefault;

    @JsonProperty("name")
    private String name;

    @JsonProperty("id")
    private long id;

    @JsonProperty("index")
    private long index;

    public void setName(String name) {
        this.name = CommonUtilComponent.getOrderedStatusName(name);
    }
}
