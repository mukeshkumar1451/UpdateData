package com.cognizant.collector.jira.beans.zephyrscale.customfield;

import com.cognizant.collector.jira.util.*;
import com.fasterxml.jackson.databind.annotation.*;
import lombok.*;

import java.util.*;

@Data
@JsonDeserialize(using = CustomFieldInfoDeserializer.class)
public class CustomFieldInfo {

    private Map<Long, CustomField> customFields= new HashMap<>();

}
