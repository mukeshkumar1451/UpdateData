package com.cognizant.collector.jira.beans.zephyrscale.testrun;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
public class ExecutionSummary {

    @JsonProperty("Not Executed")
    private int notExecuted;
    @JsonProperty("Deferred")
    private int deferred;

}
