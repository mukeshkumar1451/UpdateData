package com.cognizant.collector.jira.beans.zephyrscale.testcase;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

import java.util.*;

@Data
public class TestCaseInfo {

    @JsonProperty("results")
    private List<TestCase> testCases = new ArrayList<TestCase>();

    @JsonProperty("total")
    private long total;

    @JsonProperty("startAt")
    private long startAt;

    @JsonProperty("maxResults")
    private long maxResults;

    @JsonProperty("last")
    private boolean last;

}
