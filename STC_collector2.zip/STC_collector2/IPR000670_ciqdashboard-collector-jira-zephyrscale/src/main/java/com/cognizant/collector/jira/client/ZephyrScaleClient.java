package com.cognizant.collector.jira.client;

import com.cognizant.collector.jira.beans.zephyrscale.customfield.*;
import com.cognizant.collector.jira.beans.zephyrscale.folder.*;
import com.cognizant.collector.jira.beans.zephyrscale.testcase.*;
import com.cognizant.collector.jira.beans.zephyrscale.testrun.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

public interface ZephyrScaleClient {

    @GetMapping("/rest/tests/1.0/project/{projectId}/foldertree/testcase")
    FolderTree getTestCaseFolderTree(
                                    @PathVariable("projectId") String projectId,
                                    @RequestHeader("Cookie") String strCookie
    );

    @GetMapping("/rest/tests/1.0/project/{projectId}/foldertree/testrun")
    FolderTree getTestRunFolderTree(
            @PathVariable("projectId") String projectId,
            @RequestHeader("Cookie") String strCookie
    );

    @GetMapping("/rest/tests/1.0/project/{projectId}/customfields/testcase")
    CustomFieldInfo getCustomFields(
                                    @PathVariable("projectId") String projectId,
                                    @RequestHeader("Cookie") String strCookie
    );


    @GetMapping("/rest/atm/1.0/testrun/search")
    List<TestRun> getTestRuns(
                                    @RequestHeader("Cookie") String strCookie,
                                    @RequestParam("maxResults") int maxResults,
                                    @RequestParam("startAt") int startAt,
                                    @RequestParam("query") String query
    );


    @GetMapping("/rest/tests/1.0/testcase/search")
    TestCaseInfo getTestCases(
                                    @RequestHeader("Cookie") String strCookie,
                                    @RequestParam("maxResults") int maxResults,
                                    @RequestParam("startAt") int startAt,
                                    @RequestParam("query") String query,
                                    @RequestParam("fields") String fields
    );

}
