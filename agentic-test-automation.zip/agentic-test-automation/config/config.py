import os
from dotenv import load_dotenv

class Config:
    """
    Loads and exposes environment variables for the entire project.
    This class ensures all secrets and keys come from .env.
    """

    def __init__(self):
        # Load .env file
        load_dotenv()

        # MongoDB
        self.MONGO_URI = os.getenv("MONGO_URI")
        self.MONGO_DB = os.getenv("MONGO_DB")
        self.MONGO_COLLECTION = os.getenv("MONGO_COLLECTION", "testcases")

        # LLM: DeepSeek / Azure OpenAI
        
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")
        self.llm_model = os.getenv("LLM_MODEL", "gemini-2.5-flash")





    def validate(self):
        """
        Validate required configuration.
        Raise errors early before the workflow starts.
        """
        if not self.MONGO_URI:
            raise ValueError("Missing MONGO_URI in .env")

        if not self.MONGO_DB:
            raise ValueError("Missing MONGO_DB in .env")

        if not self.gemini_api_key:
            raise Exception("Missing Gemini API Key!")


        return True


# Singleton instance to use across project
config = Config()
