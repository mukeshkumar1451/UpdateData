import os
import zipfile
from datetime import datetime


def zip_project(module_name: str):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_name = f"{module_name}_{timestamp}.zip"

    export_folder = "exports"
    os.makedirs(export_folder, exist_ok=True)

    zip_path = os.path.join(export_folder, zip_name)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        
        # Include generated TS scripts
        module_output_path = f"output/{module_name}"
        if os.path.exists(module_output_path):
            for root, dirs, files in os.walk(module_output_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, ".")
                    zipf.write(file_path, arcname)

        # Include project source code
        for root, dirs, files in os.walk("src"):
            for file in files:
                path = os.path.join(root, file)
                arc = os.path.relpath(path, ".")
                zipf.write(path, arc)

        # Include requirements.txt
        if os.path.exists("requirements.txt"):
            zipf.write("requirements.txt")

        # Include README if available
        if os.path.exists("README.md"):
            zipf.write("README.md")

    return zip_path
