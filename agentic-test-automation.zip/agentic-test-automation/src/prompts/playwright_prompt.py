from langchain.prompts import PromptTemplate

PLAYWRIGHT_TS_PROMPT = PromptTemplate(
    input_variables=["title", "description", "steps", "expected_result"],
    template="""
You are an expert in Playwright automation using TypeScript.

Generate a **complete and executable** Playwright test script (.ts) based on the testcase below.

### Testcase
Title: {title}
Description: {description}
Steps: {steps}
Expected Result: {expected_result}

### Requirements
- Use Playwright Test (`@playwright/test`)
- Use `test.describe`, `test`, and `expect`
- Add clear comments for each step
- Use async/await everywhere
- DO NOT add mock data
- DO NOT assume URLs except: login page = "https://example.com/login"
- Use valid TypeScript syntax ONLY

### Output Format
Return ONLY the TypeScript code. No explanation.
"""
)
