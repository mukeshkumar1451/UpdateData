from langchain_core.output_parsers import StrOutputParser
from langchain.chains import LLMChain
from prompts.playwright_prompt import PLAYWRIGHT_TS_PROMPT
from llm.llm_client import llm

class PlaywrightScriptAgent:

    def __init__(self):
        self.chain = LLMChain(
            llm=llm,
            prompt=PLAYWRIGHT_TS_PROMPT,
            output_parser=StrOutputParser()
        )

    def generate_script(self, testcase):
        return self.chain.run(
            title=testcase["title"],
            description=testcase["description"],
            steps=testcase["steps"],
            expected_result=testcase["expected_result"]
        )
