from pymongo import MongoClient
from config.config import config


class MongoClientWrapper:
    """
    MongoDB client wrapper used to fetch testcases
    based on module name (e.g., 'login', 'checkout').
    """

    def __init__(self):
        # Connect to MongoDB using config values
        self.client = MongoClient(config.MONGO_URI)
        self.db = self.client[config.MONGO_DB]
        self.collection = self.db[config.MONGO_COLLECTION]

    def get_testcases(self, module: str):
        """
        Return all testcases for a given module name.
        
        Mongo DB Document Format:
        {
            "module": "login",
            "title": "...",
            "steps": [...],
            ...
        }
        """
        query = {"module": module.lower().strip()}

        results = list(self.collection.find(query, {"_id": 0}))  # remove _id

        return results

    def get_all_modules(self):
        """
        Return list of distinct module names in the collection.
        """
        return self.collection.distinct("module")
    
    

def load_testcases(module_name):
    print("Running workflow...")



# Singleton instance for reuse
mongo = MongoClientWrapper()
