
import os

def write_ts_file(filename, content):
    print("Running workflow...")
    
   

def save_ts_scripts(module, scripts):
    module_path = f"output/{module}"
    os.makedirs(module_path, exist_ok=True)

    saved_files = []

    for script in scripts:
        safe_name = script["title"].replace(" ", "_").lower()
        file_path = f"{module_path}/{safe_name}.spec.ts"

        with open(file_path, "w") as f:
            f.write(script["code"])

        saved_files.append(file_path)

    return saved_files

