from langgraph.graph import StateGraph, END
from src.agent.state import TestGenerationState

# Import Nodes
from src.agent.nodes.testcase_reader import TestcaseReaderNode
from src.agent.nodes.generator_node import GeneratorNode
from src.agent.nodes.validator_node import ValidatorNode
from src.agent.nodes.writer_node import WriterNode
from src.agent.nodes.packager_node import PackagerNode


def build_graph():
    """
    Build the LangGraph workflow for test generation.
    """

    workflow = StateGraph(TestGenerationState)

    # Instantiate nodes
    reader = TestcaseReaderNode()
    generator = GeneratorNode()
    validator = ValidatorNode()
    writer = WriterNode()
    packager = PackagerNode()

    # Add nodes to workflow
    workflow.add_node("read_testcases", reader.run)
    workflow.add_node("generate_scripts", generator.run)
    workflow.add_node("validate_code", validator.run)
    workflow.add_node("write_files", writer.run)
    workflow.add_node("package_zip", packager.run)

    # Set workflow order
    workflow.set_entry_point("read_testcases")

    workflow.add_edge("read_testcases", "generate_scripts")
    workflow.add_edge("generate_scripts", "validate_code")
    workflow.add_edge("validate_code", "write_files")
    workflow.add_edge("write_files", "package_zip")
    workflow.add_edge("package_zip", END)

    # Compile the graph
    return workflow.compile()
