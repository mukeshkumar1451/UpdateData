from src.db.mongo_client import mongo
from src.agent.state import TestGenerationState


class TestcaseReaderNode:

    def run(self, state: TestGenerationState) -> TestGenerationState:
        module = state.get("module")

        testcases = mongo.get_testcases(module)

        if not testcases:
            raise Exception(f"No testcases found for module: {module}")

        state["testcases"] = testcases
        return state
