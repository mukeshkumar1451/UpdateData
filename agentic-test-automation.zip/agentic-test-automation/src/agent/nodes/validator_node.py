from src.agent.state import TestGenerationState


class ValidatorNode:

    def run(self, state: TestGenerationState) -> TestGenerationState:
        validated = []

        for code in state.get("generated_scripts", []):
            if not code or "test(" not in code:
                raise Exception("Generated code invalid or empty")
            validated.append(code)

        state["generated_scripts"] = validated
        return state
