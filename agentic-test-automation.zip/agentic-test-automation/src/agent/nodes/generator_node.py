from src.llm.llm_client import llm
from src.agent.state import TestGenerationState


class GeneratorNode:

    def run(self, state: TestGenerationState) -> TestGenerationState:
        testcases = state.get("testcases", [])

        generated_scripts = []

        for tc in testcases:
            ts_code = llm.generate_code(tc)
            generated_scripts.append(ts_code)

        state["generated_scripts"] = generated_scripts
        return state
