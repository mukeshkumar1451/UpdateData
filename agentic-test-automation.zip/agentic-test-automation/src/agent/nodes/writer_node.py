import os
from src.agent.state import TestGenerationState


class WriterNode:

    def run(self, state: TestGenerationState) -> TestGenerationState:

        module = state["module"]
        scripts = state["generated_scripts"]

        output_dir = f"output/{module}"
        os.makedirs(output_dir, exist_ok=True)

        file_paths = []

        for idx, code in enumerate(scripts, start=1):
            path = f"{output_dir}/test_{module}_{idx}.spec.ts"
            with open(path, "w") as f:
                f.write(code)
            file_paths.append(path)

        state["output_files"] = file_paths
        return state
