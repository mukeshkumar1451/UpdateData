import zipfile
import os
from src.agent.state import TestGenerationState


class PackagerNode:

    def run(self, state: TestGenerationState) -> TestGenerationState:
        module = state["module"]
        files = state["output_files"]

        zip_path = f"output/{module}_tests.zip"

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for file in files:
                z.write(file, os.path.basename(file))

        state["zip_path"] = zip_path
        return state
