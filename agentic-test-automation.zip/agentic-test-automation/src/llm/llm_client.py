import google.generativeai as genai
from config.config import config


class LLMClient:

    def __init__(self):
        # Configure Gemini API Key
        genai.configure(api_key=config.gemini_api_key)
        self.model = genai.GenerativeModel(config.llm_model)

    def generate(self, prompt: str) -> str:
        """Send prompt to Gemini and return text response."""
        response = self.model.generate_content(prompt)

        # Safe extraction for text response
        try:
            return response.text
        except:
            return response.candidates[0].content.parts[0].text

    def generate_code(self, testcase: dict, framework: str = "playwright") -> str:
        """
        Convert a JSON testcase into a TypeScript Playwright script (.spec.ts)
        """

        prompt = f"""
You are an expert QA automation engineer. Convert the following testcase 
into a valid Playwright TypeScript test file (.spec.ts).

Testcase JSON:
{testcase}

Requirements:
- Use Playwright Test format
- Import from '@playwright/test'
- Use test.describe() and test()
- Convert steps into real Playwright actions
- Produce ONLY pure TypeScript code, no backticks, no commentary
- Output must be a ready-to-save .spec.ts file
"""

        return self.generate(prompt)


# Singleton instance
llm = LLMClient()
