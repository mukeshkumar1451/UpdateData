from langgraph.graph import StateGraph, END
from typing import TypedDict, List, Dict

from agents.playwright_generator_agent import PlaywrightScriptAgent
from writers.ts_writer import save_ts_scripts
from mongo.mongo_client import load_testcases
from utils.zip_exporter import zip_project



# ---------------------------------------------------------------------
# 1. STATE DEFINITION
# ---------------------------------------------------------------------
class TestState(TypedDict):
    module: str
    testcases: List[Dict]
    scripts: List[Dict]
    output_files: List[str]


# ---------------------------------------------------------------------
# 2. INITIALIZE AGENT
# ---------------------------------------------------------------------
playwright_agent = PlaywrightScriptAgent()


# ---------------------------------------------------------------------
# 3. NODE FUNCTIONS
# ---------------------------------------------------------------------

# Load testcases from MongoDB
def load_testcases_node(state: TestState):
    module = state["module"]
    tcs = load_testcases(module)
    return {"testcases": tcs}





# LLM → Generate Playwright scripts
def playwright_node(state: TestState):
    scripts = []

    for tc in state["testcases"]:
        ts_code = playwright_agent.generate_script(tc)
        scripts.append({
            "title": tc["title"],
            "code": ts_code
        })

    return {"scripts": scripts}


# Save .ts files
def save_ts_node(state: TestState):
    module = state["module"]
    out = save_ts_scripts(module, state["scripts"])
    return {"output_files": out}

def zip_node(state):
    zip_path = zip_project(state["module"])
    return {"zip_file": zip_path}


# ---------------------------------------------------------------------
# 4. BUILD LANGGRAPH WORKFLOW
# ---------------------------------------------------------------------

builder = StateGraph(TestState)

# -------------------------------
# REGISTER NODES
# -------------------------------
builder.add_node("load_testcases", load_testcases_node)
builder.add_node("generate_playwright_ts", playwright_node)   # STEP 14.4
builder.add_node("save_ts_files", save_ts_node)               # STEP 14.6
builder.add_edge("save_ts_files", "zip_export")
builder.add_edge("zip_export", END)


# -------------------------------
# REGISTER EDGES
# -------------------------------
builder.add_edge("load_testcases", "generate_playwright_ts")  
builder.add_edge("generate_playwright_ts", "save_ts_files")   
builder.add_edge("save_ts_files", END)

# compile workflow
workflow = builder.compile()

# ---------------------------------------------------------------------
# 5. EXECUTION WRAPPER WITH 
# ---------------------------------------------------------------------

def run_graph(module_name: str):
    print("Starting workflow...")

    try:
        result = workflow.invoke({
            "module": module_name,
            "testcases": [],
            "scripts": [],
            "output_files": [],
            "zip_file": ""
        })

        print("Workflow completed successfully.")
        return result

    except Exception as e:
        print(f"Workflow failed: {e}")
        raise e
