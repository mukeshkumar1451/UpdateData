import sys
import argparse
from src.agent.graph import build_graph
from config.config import config


def run_workflow(module_name: str):
    """
    Execute the LangGraph workflow for the given module.
    """

    # Validate config first
    config.validate()

    print(f"\n🚀 Starting test generation for module: {module_name}")

    graph = build_graph()

    # Initial state
    initial_state = {
        "module": module_name.lower().strip()
    }

    # Execute workflow
    final_state = graph.invoke(initial_state)

    zip_path = final_state.get("zip_path")

    if zip_path:
        print(f"\n✅ Test script generation completed!")
        print(f"📦 ZIP file created: {zip_path}")
    else:
        print("\n❌ Failed: No ZIP produced.")

    return zip_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Agentic AI TestScript Generator")
    parser.add_argument(
        "module",
        type=str,
        help="Module name to generate test scripts for (example: login)"
    )

    args = parser.parse_args()

    run_workflow(args.module)
