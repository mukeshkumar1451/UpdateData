import { test, expect } from '@playwright/test';

test.describe('login module: Validate user can login successfully.', () => {
  const validUsername = 'testuser';
  const validPassword = 'testpassword';

  test('Login with valid credentials', async ({ page }) => {
    await page.goto('/login');

    await page.fill('input[name="username"]', validUsername);
    await page.fill('input[name="password"]', validPassword);

    await page.click('button[type="submit"]');

    await expect(page).toHaveURL(/.*dashboard/);
  });
});