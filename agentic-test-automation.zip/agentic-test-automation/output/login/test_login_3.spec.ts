import { test, expect } from '@playwright/test';

test.describe('login module', () => {
  // description: Check validation when submitting without input.
  test('Login with empty fields', async ({ page }) => {
    // Step 1: Navigate to login page
    // Assuming the base URL is configured in playwright.config.ts
    // and '/login' is the path to the login page.
    await page.goto('/login');

    // Step 2: Leave username blank (no action needed as fields are initially empty)
    // Step 3: Leave password blank (no action needed as fields are initially empty)

    // Step 4: Click Login button
    // This assumes there is a button with the accessible name 'Login'.
    // Adjust the locator if your login button has a different text, id, or role.
    await page.getByRole('button', { name: 'Login' }).click();

    // Expected Result: Validation messages appear for both fields
    // These locators assume specific validation messages for empty username and password.
    // Adjust 'Username is required' and 'Password is required' to match the actual
    // validation text displayed by your application.
    await expect(page.locator('text=Username is required')).toBeVisible();
    await expect(page.locator('text=Password is required')).toBeVisible();
  });
});