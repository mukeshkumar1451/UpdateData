import { test, expect } from '@playwright/test';

test.describe('login module', () => {
  test('Login with invalid password', async ({ page }) => {
    // Precondition: User account exists
    // This implies that a valid username is known for the system under test.
    // For the purpose of this test, we'll use 'validuser' as a placeholder.

    // Step 1: Navigate to login page
    // Assuming '/login' is the relative path to the login page.
    // Ensure your playwright.config.ts has a 'baseURL' configured or provide a full URL.
    await page.goto('/login');

    // Step 2: Enter valid username
    // Adjust the selector 'input[name="username"]' to match your application's username input field.
    await page.fill('input[name="username"]', 'validuser');

    // Step 3: Enter invalid password
    // Adjust the selector 'input[name="password"]' to match your application's password input field.
    await page.fill('input[name="password"]', 'incorrectpassword123');

    // Step 4: Click Login button
    // Adjust the selector 'button[type="submit"]' to match your application's login button.
    // Common alternatives: 'input[type="submit"]', 'button:has-text("Login")', '#loginButton'
    await page.click('button[type="submit"]');

    // Expected Result: Error message 'Invalid credentials' is displayed
    // Adjust the selector '.error-message' to precisely target the element where the error message appears.
    // Common alternatives: '#errorMessage', 'div[role="alert"]', 'p.error'
    const errorMessageLocator = page.locator('.error-message');

    await expect(errorMessageLocator).toBeVisible();
    await expect(errorMessageLocator).toHaveText('Invalid credentials');
  });
});