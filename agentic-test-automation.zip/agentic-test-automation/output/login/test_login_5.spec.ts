import { test, expect } from '@playwright/test';

test.describe('login module', () => {
  test('Remember Me functionality', async ({ page, browser }) => {
    // Preconditions: User account exists (assumed for this test)

    await test.step('Navigate to login page', async () => {
      await page.goto('/login'); // Adjust URL to your application's login page
      await expect(page).toHaveURL(/.*login/);
    });

    await test.step('Enter valid username', async () => {
      await page.fill('input[name="username"]', 'testuser'); // Adjust selector and test username
    });

    await test.step('Enter valid password', async () => {
      await page.fill('input[name="password"]', 'password123'); // Adjust selector and test password
    });

    await test.step("Check 'Remember Me' box", async () => {
      await page.check('input[type="checkbox"][name="rememberMe"]'); // Adjust selector for 'Remember Me' checkbox
      await expect(page.locator('input[type="checkbox"][name="rememberMe"]')).toBeChecked();
    });

    await test.step('Click Login button', async () => {
      await page.click('button[type="submit"]'); // Adjust selector for the login button
      // Wait for navigation to the dashboard or a unique element on it
      await page.waitForURL(/.*dashboard/); // Adjust URL to your application's dashboard path
      await expect(page).toHaveURL(/.*dashboard/);
    });

    // Store the current authentication state after successful login with "Remember Me"
    const storageState = await page.context().storageState();

    await test.step('Close and reopen browser (simulated)', async () => {
      // Create a new browser context using the stored state.
      // This simulates opening a new browser session where the 'Remember Me' feature should keep the user logged in.
      const newContext = await browser.newContext({ storageState });
      const newPage = await newContext.newPage();

      // Navigate directly to a protected page (e.g., the dashboard).
      // If 'Remember Me' worked, the user should be logged in without needing to re-authenticate.
      await newPage.goto('/dashboard'); // Adjust URL to your application's protected dashboard page

      // Expected Result: User remains logged in and sees dashboard
      await expect(newPage).toHaveURL(/.*dashboard/);
      await expect(newPage.locator('h1')).toHaveText('Dashboard'); // Adjust selector and text for a dashboard title or element
      await expect(newPage.locator('text=Welcome, testuser')).toBeVisible(); // Adjust selector for a personalized welcome message

      await newContext.close(); // Close the new context to clean up resources
    });
  });
});