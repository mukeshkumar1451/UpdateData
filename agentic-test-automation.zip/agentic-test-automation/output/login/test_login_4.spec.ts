import { test, expect } from '@playwright/test';

test.describe('Login Module', () => {
  test('Login with locked account', async ({ page }) => {
    // Description: Ensure locked users cannot login.
    // Preconditions: User account is locked.

    // Step 1: Navigate to login page
    await page.goto('/login'); // Assuming '/login' is the path to your login page

    // Step 2: Enter locked username
    // Replace '#usernameInput' with the actual selector for the username field
    // Replace 'lockedUser' with an actual username that is known to be locked in your test environment
    await page.fill('#usernameInput', 'lockedUser');

    // Step 3: Enter correct password
    // Replace '#passwordInput' with the actual selector for the password field
    // Replace 'correctPassword123' with the correct password for the 'lockedUser'
    await page.fill('#passwordInput', 'correctPassword123');

    // Step 4: Click Login button
    // Replace '#loginButton' with the actual selector for the login button
    await page.click('#loginButton');

    // Expected Result: Message 'Account is locked' is displayed
    // Replace 'text="Account is locked"' with a more specific locator if the message is in a dedicated element (e.g., '#errorMessage', '.error-message-locked')
    await expect(page.locator('text="Account is locked"')).toBeVisible();
  });
});